#Realizar Cadastro

Dado('que acesso a tela de Login') do
  @login_page.acesso_cvc
  @cadastro_page.clicar_cadastrar
end

Dado('preencho os campos {string}, {string} e {string} na tela de Login') do |nome, email, senha|
  @nome = nome
  @cadastro_page.faz_cadastro(nome,email,senha)
end
    
Então('usuário é criado') do
  sleep 3
  expect(page).to have_content @nome
end

#Acessando a pagina do Perfil
Quando('eu clico em nome do usuario') do
  @cadastro_page.consulta_perfil
end
  
Então('acesso a tela de perfil') do
  #expect(page).to have_content @nome
end
  
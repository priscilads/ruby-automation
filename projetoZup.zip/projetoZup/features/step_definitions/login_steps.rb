 #Ralizar Login
  Dado('que eu acesso a pagina principal da CVC') do
    @login_page.acesso_cvc
  end

  Dado('vou para a tela de Login') do
    @login_page.clicar_entrar
  end

  Dado('preencho as informações de {string} e {string}') do |email, senha|
    @login_page.faz_login(email,senha)
  end
  
  Então('usuário é autenticado') do
    #expect(page).to have_content nome
  end


  #Quando eu realizo o Login errado - Tentativa de login
  Então('devo ver a mensagem {string}') do |mensagem|
    expect(page).to have_content mensagem
  end


  

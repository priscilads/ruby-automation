class CadastroPage

    include Capybara::DSL

    def clicar_cadastrar
        click_on 'Entrar'
        click_on 'Ok, entendi'
        click_on 'CADASTRAR'
    end

    def faz_cadastro(nome,email,senha)
        sleep 1
        find("input[name=name]").set nome   
        find(:xpath, '//*[@id="email"]').set email
        find("input[name=password]").set senha
        sleep 2
        click_button "CADASTRAR"
    end

    def consulta_perfil
        sleep 5
        find(:xpath, "/html/body/am-header-wc/div/nav/div[2]/am-login/div/span[2]/p[2]").click
        sleep 2
        click_on "Perfil"
    end


end
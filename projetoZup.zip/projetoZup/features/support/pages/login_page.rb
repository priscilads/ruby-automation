class LoginPage

    include Capybara::DSL

    def acesso_cvc
    visit 'https://www.cvc.com.br'
    page.driver.browser.manage.window.maximize
    sleep 8
    end

    def clicar_entrar
    click_on 'Entrar'
    click_on 'Ok, entendi'
    click_on 'ENTRAR'
    end
    
    def faz_login(email,senha)
    sleep 1    
    find(:xpath, '//*[@id="email"]').set email
    find("input[name=password]").set senha
    sleep 2
    click_button "ENTRAR"
    end
end


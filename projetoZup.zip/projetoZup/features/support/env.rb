require 'capybara'
require 'capybara/cucumber'
require 'rspec/expectations'
require "selenium-webdriver"
require "os"

Capybara.configure do |config|
    config.default_driver =:selenium_chrome
end

Capybara.ignore_hidden_elements = false
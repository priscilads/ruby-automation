#Responsavel por instanciar as classes antes do de iniciar o step_definition
Before do
    @login_page = LoginPage.new
    @cadastro_page = CadastroPage.new
  end
  

